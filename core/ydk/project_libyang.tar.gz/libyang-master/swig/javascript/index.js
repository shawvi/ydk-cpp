'use strict';

module.exports = require("./build/Release/yang")
